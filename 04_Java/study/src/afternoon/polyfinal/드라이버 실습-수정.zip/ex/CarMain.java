package afternoon.polyfinal.ex;

import java.io.InputStreamReader;

public class CarMain {
    public static void main(String[] args) {
        Driver driver = new Driver();

        driver.selectCar();
    }
}
