package afternoon.polyfinal.ex;

public interface Car {
    void openDoor();
    void drive();
}
